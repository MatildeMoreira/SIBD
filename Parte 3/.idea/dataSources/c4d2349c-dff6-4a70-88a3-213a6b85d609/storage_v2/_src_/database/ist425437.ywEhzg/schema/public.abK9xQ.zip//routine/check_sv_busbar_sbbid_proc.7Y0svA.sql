create function check_sv_busbar_sbbid_proc() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (NEW.sv) NOT IN (SELECT b.voltage FROM busbar as b WHERE NEW.sbbid = b.id) THEN
        RAISE EXCEPTION 'The secondary voltage of the transformer must correspond to the voltage of the busbar identified by sbbid.';
        END IF;
        RETURN NEW;

END;
$$;

alter function check_sv_busbar_sbbid_proc() owner to ist425437;

