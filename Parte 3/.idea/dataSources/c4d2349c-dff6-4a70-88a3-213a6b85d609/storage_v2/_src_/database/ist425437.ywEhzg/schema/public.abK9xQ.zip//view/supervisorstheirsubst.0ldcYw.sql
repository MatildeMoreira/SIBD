create view supervisorstheirsubst(name, address, n_substations) as
SELECT s.name,
       s.address,
       count(*) AS n_substations
FROM supervisor s
         LEFT JOIN substation sub ON s.name::text = sub.sname::text AND s.address::text = sub.saddress::text
WHERE sub.sname IS NOT NULL
  AND sub.saddress IS NOT NULL
GROUP BY s.name, s.address
ORDER BY s.name, s.address;

alter table supervisorstheirsubst
    owner to ist425437;

