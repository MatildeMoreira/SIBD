create function check_analystsubstation_proc() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (NEW.id,New.name,NEW.address) IN (SELECT id,sname,saddress FROM transformer LEFT OUTER JOIN substation s on s.gpslat = transformer.gpslat and s.gpslong = transformer.gpslong) THEN
            RAISE EXCEPTION 'The analyst cannot anlyse incidents regarding Elements of a Substation they supervises.'
            USING HINT = 'Please check the name and address of the analyst)';
        END IF;

        RETURN NEW;

END;
$$;

alter function check_analystsubstation_proc() owner to ist425437;

