create function check_pv_busbar_pbbid_proc() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (NEW.pv) NOT IN (SELECT b.voltage FROM busbar as b WHERE NEW.pbbid = b.id) THEN
        RAISE EXCEPTION 'The primary voltage of the transformer must correspond to the voltage of the busbar identified by pbbid.';
        END IF;
        RETURN NEW;

END;
$$;

alter function check_pv_busbar_pbbid_proc() owner to ist425437;

