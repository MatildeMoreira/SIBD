create function load_d_time() returns void
    language plpgsql
as
$$
DECLARE time_val TIMESTAMP;
BEGIN
    time_val := '2020-01-01 00:00:00';
    WHILE time_val < '2020-12-31 00:00:00' LOOP
        INSERT INTO d_time(
            id_time,
            day,
            week_day,
            week,
            month,
            trimester,
            year
        ) VALUES (
              EXTRACT(YEAR FROM time_val) * 10000
              +   EXTRACT(MONTH FROM time_val)*100
              +   EXTRACT(DAY FROM time_val),
              EXTRACT(DAY FROM time_val),
              EXTRACT(DOW FROM time_val),
              EXTRACT(WEEK FROM time_val),
              EXTRACT(MONTH FROM time_val),
              CASE
                    WHEN EXTRACT(MONTH FROM time_val) BETWEEN 0 AND 3 THEN 1
                    WHEN EXTRACT(MONTH FROM time_val) BETWEEN 4 AND 6 THEN 2
                    WHEN EXTRACT(MONTH FROM time_val) BETWEEN 7 AND 9 THEN 3
                    ELSE 4
              END,
              EXTRACT(YEAR FROM time_val)
        );
        time_val := time_val + INTERVAL '1 DAY';
    END LOOP;
END;
$$;

alter function load_d_time() owner to ist425437;

